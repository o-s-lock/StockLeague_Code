#!/usr/bin/env python
# coding: utf-8


###############################################
#                                             #
#　        テキストマイニング前処理パッケージ  　　     #
#　　　　　        by Y.Maeda　　                #
#　　　created :       2001/05/28 　            # 
#     last modified : 2001/06/25 　            #
#                                             #
###############################################

import pandas as pd
import MeCab
import collections
import re

HinshiChange = [['きた', '動詞', 'くる'], ['出て', '動詞', '出る']]


########################################
#
# ＜＜＜キーワードが入っている分のみ抽出＞＞＞
#
########################################

def keywordEx(text, キーワード, psw = True):
    NewText = ''
    lines = re.split('[。．]', text)
    n = 0
    cont = ''
    for line in lines:
        #if line != '\n':
        if any((s in line) for s in キーワード):
            line2 = line.replace('\n', '')
            n = n+1
            if psw:
                print(n, ':', line2)
            cont = cont + line2 + '。'
    NewText += cont
    return(NewText)
  

def morphANNew(res, combineNoun = False, useOriginal = False, psw = False):
    terms = [["dummy", "dummy", "dummy"]]
    termsCount = 0;
    while res:
        term = []
        term.append(res.surface)
        #print('term:', term)
        for arr in res.feature.split(","):
            term.append(arr)
        #print('term.append(arr):', term)
        if useOriginal: #原型にするならば
            # 原型が誤っている場合に修正する
            for CH in HinshiChange:
                if term[0] in CH:
                    term[7] = CH[2]
                    if psw: print('単語変更（原型）：', term[0], term[1], term[7])
                    break
            if term[7] != "*":
                term[0] = term[7]
        if combineNoun: #名詞を複合化するならば
            # 品詞が誤っている場合に修正する
            for CH in HinshiChange:
                if term[0] in CH:
                    term[1] = CH[1]
                    term[0] = CH[2]
                    if psw: print('単語変更：', term[0], term[1])
                    break
            単語 = term[0]
            品詞 = term[1]
            品詞詳細 = term[2]
            前単語 = terms[termsCount][0]
            前品詞 = terms[termsCount][1]
            前品詞詳細 = terms[termsCount][2]
            # 名詞の結合，名詞と接尾辞の結合
            if 品詞 == '名詞' and 前品詞 == '名詞' and (前品詞詳細[-6:] != '接尾' or 品詞詳細 == '接尾'): 
                terms[termsCount][2] = terms[termsCount][2] + "+" + term[2]
                terms[termsCount][0] = terms[termsCount][0] + term[0]
                #print('termsCount=', termsCount, terms)
            # 接頭辞と名詞の結合
            elif (品詞 == '名詞' and 前品詞 == '接頭詞' and (前品詞詳細 == '名詞接続' or 前品詞詳細 == '数接続')): 
                terms[termsCount][2] = terms[termsCount][2] + "+" + term[2]
                terms[termsCount][0] = terms[termsCount][0] + term[0]
                terms[termsCount][1] = '名詞'
                #print('termsCount=', termsCount, terms)
            # 名詞と名詞の結合（<<ここは確認必要>>）
            elif (品詞 == '接頭詞' and 前品詞 == '名詞'): 
                terms[termsCount][2] = terms[termsCount][2] + "+" + term[2]
                terms[termsCount][0] = terms[termsCount][0] + term[0]
                terms[termsCount][1] = '名詞'
                #print('termsCount=', termsCount, terms)    
            else:
                terms.append(term)
                termsCount = termsCount + 1
        else: #名詞を複合化しないならそのまま追加
            terms.append(term)
            termsCount = termsCount + 1
        #if termsCount == 5:
        #   print('term==', term)
        res = res.next
    terms.pop(0)
    return terms

def wordCheck(m, exwords):
    fg = True
    #　exwordsの排除
    if m[0] in exwords:
        fg = False #　exwordsの排除
    # 全角数字のみの単語（業績予想含む）の排除
    if re.fullmatch('[０-９．・]+予?', m[0]) != None:
        fg = False
    # 代名詞を排除
    if m[1] == '名詞' and m[2] == '代名詞':
        fg = False
    # 非自立の名詞を排除
    if m[1] == '名詞' and m[2] == '非自立':
        fg=False
    return(fg)

def POSFilter2New(morphomes, exwords, verbFilter = False, exceptPOSs = []):
    filteredMorphomes = []
    words= []
    for m in morphomes:
        #単語のチェック
        if wordCheck(m,exwords):
            if verbFilter: #非自立の動詞，および "する" を除去
                if m[1] == "動詞":
                    if m[0] == "する":
                        continue
                    elif m[2] != "自立":
                        continue
            flag = False
            for e in exceptPOSs: #品詞でフィルタ
                if m[1] == e:
                    flag = True
                    break
            if flag:
                continue
            filteredMorphomes.append(m)
            #print('m=', m[0])
            words.append(m[0])
    return words


